//vehicles js va a exportar un array
const vehicles = [
    {
      name: "Carro",
      description: "Tiene cuatro llantas y cuatro puertas",
      image:
        "https://thumbor.forbes.com/thumbor/fit-in/1200x0/filters%3Aformat%28jpg%29/https%3A%2F%2Fspecials-images.forbesimg.com%2Fimageserve%2F5d35eacaf1176b0008974b54%2F0x0.jpg%3FcropX1%3D790%26cropX2%3D5350%26cropY1%3D784%26cropY2%3D3349",
    },
    {
      name: "Motocicleta",
      description: "Tiene dos llantas y va rapido",
      image:
        "https://content2.kawasaki.com/ContentStorage/KMC/Products/8798/8c85b065-f4e9-4ee6-966f-2b7993daff08.png?w=767",
    },
    {
      name: "Bicicleta",
      description: "Es un buen transporte para el medio ambiente",
      image:
        "https://media.wired.com/photos/63e569c9de59d567d5d7c66d/master/w_2240,c_limit/Ride1Up-Cafe-Cruiser-Featured-Gear.jpg",
    },
    {
      name: "Avion",
      description: "Los tickets son caros ",
      image: "https://www.rd.com/wp-content/uploads/2020/01/GettyImages-1131335393-e1650030686687.jpg",
    },
    {
      name: "Barco",
      description: "Es pesado y va sobre el mar",
      image: "https://www.marineinsight.com/wp-content/uploads/2019/08/Cruise-ships-1.png",
    },
    {
      name: "Astronave",
      description: "Va al espacio",
      image:
        "https://img.freepik.com/premium-photo/futuristic-scifi-battle-spaceship-hover-ocean-alien-planet-digital-painting_379823-2914.jpg?w=2000",
    },
  ];
  
  export default vehicles;